import React from 'react'

export default function App() {
  return (
    <div className='p-10 text-center'>
      <h1 className='text-3xl font-bold text-emerald-700'>Relamping LED - Corse & DOM-TOM</h1>
      <p className='mt-4'>Remplacez ce fichier par votre code complet fourni.</p>
    </div>
  )
}
